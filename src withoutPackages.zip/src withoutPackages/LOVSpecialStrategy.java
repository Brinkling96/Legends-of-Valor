package src;

public interface LOVSpecialStrategy {
	//interface for LOV cells which can doSpecialStrategy
    void doSpecialStrategy();
}
