package src;

public class LOVMonsterNexus extends LOVCell{
	// the class represent Monster Nexus cells which extend LOVCell
    public LOVMonsterNexus(int row, int col) {
        super(row, col, 'V');
    }

}
