

public interface canBuyAndSell {

	//interface for items which can buy and can be sold
	
	public String getItemName();
	public int getPrice();
	public int getLevelReq();
}
