

import java.util.ArrayList;

//the class initializes all heroes
public interface HeroFactory {
    ArrayList<Hero> createParty();
}
