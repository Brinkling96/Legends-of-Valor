

public interface BoardFactory {
	//the class initializes board
    Board createBoard(int row, int column);
}
